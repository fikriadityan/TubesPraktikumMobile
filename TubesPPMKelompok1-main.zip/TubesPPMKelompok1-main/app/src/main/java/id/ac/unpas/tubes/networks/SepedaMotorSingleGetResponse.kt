package id.ac.unpas.tubes.networks

import id.ac.unpas.tubes.model.SepedaMotor

data class SepedaMotorSingleGetResponse(
    val data: SepedaMotor? = null
)
