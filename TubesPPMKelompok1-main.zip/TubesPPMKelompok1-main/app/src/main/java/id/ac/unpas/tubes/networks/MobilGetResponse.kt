package id.ac.unpas.tubes.networks

import id.ac.unpas.tubes.model.Mobil

data class MobilGetResponse(
    val data: List<Mobil>? = null
)
