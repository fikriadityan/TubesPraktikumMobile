package id.ac.unpas.tubes.networks

import id.ac.unpas.tubes.model.Mobil

data class MobilSingleGetResponse(
    val data: Mobil? = null
)
