package id.ac.unpas.tubes.networks

import id.ac.unpas.tubes.model.Promo

data class PromoSingleGetResponse(
    val data: Promo? = null
)
