package id.ac.unpas.tubes.networks

import id.ac.unpas.tubes.model.SepedaMotor

data class SepedaMotorGetResponse(
    val data: List<SepedaMotor>? = null
)
