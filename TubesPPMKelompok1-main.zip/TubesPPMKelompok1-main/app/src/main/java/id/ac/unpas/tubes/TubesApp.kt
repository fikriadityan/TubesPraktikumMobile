package id.ac.unpas.tubes

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TubesApp: Application()