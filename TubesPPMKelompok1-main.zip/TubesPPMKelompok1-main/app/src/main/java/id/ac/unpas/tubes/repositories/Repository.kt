package id.ac.unpas.tubes.repositories

interface Repository