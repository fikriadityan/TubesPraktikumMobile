# TubesPPMKelompok1
Tugas Besar Mata Kuliah Praktikum Pemograman Mobile Kelompok 1 Kelas B 2023
- Rio Alifian Santoso - 193040057
- Fauzan Ihsanudin R - 193040047
- Muhammad Nur Firmansyah - 193040088
- Naufal Hamid - 193040059
- Fikri Aditya Nugraha  - 193040066
